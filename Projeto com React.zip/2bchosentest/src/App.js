// Import Swiper React components
import { Swiper, SwiperSlide } from 'swiper/react';

// Import Swiper styles
import 'swiper/css';

import './App.css';

function App() {
  return (


    <div>

      <header>
        <div id="stars-box">
          <img id="left-star" src="/images/bigger-star.png" alt="An image of a big star in the left side" />
          <img id="center-star" src="/images/smaller-star.png" alt="An image of a small star in the center" />
          <img id="right-star" src="/images/bigger-star.png" alt="An image of a big star in the right side" />
        </div>

        {/* Inicio do swiper */}

        <Swiper
          spaceBetween={50}
          slidesPerView={1}
          onSlideChange={() => console.log('slide change')}
          onSwiper={(swiper) => console.log(swiper)}
        >
          <SwiperSlide><img class="swiper-slide-image" src="/images/header-food.png"/></SwiperSlide>
          <SwiperSlide><img class="swiper-slide-image" src="/images/swiper-image-2.jpg"/></SwiperSlide>
          <SwiperSlide><img class="swiper-slide-image" src="/images/swiper-image-3.jpg"></img></SwiperSlide>
          ...
        </Swiper>
        {/*

    <div id="app">
      <img class="responsive-image" id="header-image" src="./images/header-food.png" alt="An image of a food plate ready to be eaten"/>
    </div>
  

  */}
      </header>
      {/* Fim do swiper */}




      <main>

        <section id="bellow-header-image-section">

          <div class="first-main-section-boxes">
            <img src="/images/eletric-door.png" alt="An image of an eletric door" />
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sem nec, augue vel mollis</p>
          </div>


          <div class="first-main-section-boxes">
            <img src="/images/sensor-door.png" alt="An image of a sensor door" />
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sem nec, augue vel mollis</p>
          </div>


          <div class="first-main-section-boxes">
            <img src="/images/banket-flower-painting.png" alt="An image of a banket, flower pot and painting in the wall" />
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sem nec, augue vel mollis</p>
          </div>

        </section>



        <section id="main-description-section">


          <div id="left-side-description-section">
            <div id="h2-description-box">
              <h2>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</h2>
            </div>

            <div id="p-description-box">
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sem nec, augue vel mollis purus mauris, posuere volutpat. Cras vel nunc commodo nulla pharetra, lectus. Sit sed in sed nunc arcu eu. Netus ligula duis quis sed dui in tortor dolor ultrices.</p>
            </div>
          </div>

          <div id="right-side-description-section">
            <img class="responsive-image" id="contemporanean-cuisine-plate-image" src="/images/contemporanean-cuisine-plate.png" alt="A photo of a contemporanean cuisine plate" />
          </div>
        </section>




        <section id="dinner-table-section">

          <img class="responsive-image" id="dinner-table-image" src="/images/dinner-table.png" alt="A photo of a served dinner table" />

        </section>




        <section id="photos-galery">

          <figure id="figure-photos-galery">

            <figcaption id="galeria-de-fotos">Galeria de Fotos</figcaption>
            <img class="responsive-image" id="breakfast-table-image" src="/images/breakfast-table.png" alt="A photo filled with food for a breakfast" />

          </figure>

          <div id="photos-galery-display">
            <div class="individual-photo-galery-box">
              <img class="responsive-image" id="photo-galery-display1" src="/images/photo-galery-display1.png" alt="A photo of a strawberry cake" />
            </div>

            <div class="individual-photo-galery-box">
              <img class="responsive-image" id="photo-galery-display2" src="/images/photo-galery-display2.png" alt="A photo of a hamburger" />
            </div>

            <div class="individual-photo-galery-box">
              <img class="responsive-image" id="photo-galery-display3" src="/images/photo-galery-display3.png" alt="A photo of a spicy dish" />
            </div>

            <div class="individual-photo-galery-box">
              <img class="responsive-image" id="photo-galery-display4" src="/images/photo-galery-display4.png" alt="A photo of a lunch dish" />
            </div>

            <div id="display5-box" class="individual-photo-galery-box">
              <img class="responsive-image" id="photo-galery-display5" src="/images/photo-galery-display5.png" alt="A photo of a hamburger with onions inside" />
            </div>

          </div>
        </section>




        <section id="contact-form">

          <div id="h2-contact-box">
            <h2>Contato</h2>
          </div>


          <form id="contato" action="test2bchosen@gmail.com">

            <div class="contact-individual-boxes">
              <label for="name">Nome<br />
                <input type="text" name="name" id="name" />
              </label>
            </div>

            <br />


            <div class="contact-individual-boxes">
              <label for="telephone">Telefone <br />
                <input type="tel" name="telephone" id="telephone" minlength="8" maxlength="18" />
              </label>
            </div>

            <br />

            <div class="contact-individual-boxes">
              <label for="email">E-Mail <br />
                <input type="email" name="email" id="email" />
              </label>
            </div>

            <br />

            <div class="contact-individual-boxes">
              <label for="message">Mensagem <br />
                <textarea type="text" name="message" id="message"></textarea>
              </label>
            </div>

            <br />

            <div id="submit-buttom" class="contact-individual-boxes">
              <input id="enviar" type="submit" value="ENVIAR" />
            </div>

          </form>


        </section>


      </main>




      <footer>
        <div id="footer-first-line">
          <span>
            <img src="/images/icon-awesome-map-marker-alt.png" alt="" />
            R. Tailândia, 72, Bairro das Nações, Balneário Camboriú-SC
          </span>
        </div>

        <div id="footer-second-line">
          <span>
            <img src="/images/icon-awesome-phone-alt.png" alt="" />
            (47) 2233-3500
          </span>
        </div>

        <div id="footer-icons-box">
          <a href="https://www.instagram.com/" target="_blank"><img class="footer-link-icons" src="/images/icon-awesome-instagram.png" alt="Click here to open 2BChosen instagran page" /></a>

          <a href="https://pt-br.facebook.com/" target="_blank"><img class="footer-link-icons" src="/images/icon-awesome-facebook-square.png" alt="Click here to open 2BChosen facebook page" /></a>

          <a href="https://br.linkedin.com/" target="_blank"><img class="footer-link-icons" src="/images/icon-awesome-linkedin.png" alt="Click here to open 2BChosen linkedin page" /></a>

          <a href="https://www.youtube.com/" target="_blank"><img class="footer-link-icons" src="/images/icon-awesome-youtube-square.png" alt="Click here to open 2BChosen youtube chanel" /></a>

        </div>
      </footer>

    </div>
  );
}

export default App;
